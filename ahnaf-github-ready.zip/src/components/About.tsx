import { motion } from 'framer-motion'

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' },
  transition: { duration: 0.8, ease: 'easeOut' }
}

export function About() {
  return (
    <section id="about" className="section-padding">
      <div className="max-w-7xl mx-auto">
        {/* Section Label */}
        <motion.div {...fadeInUp} className="mb-16">
          <span className="text-sm text-gray-500 tracking-widest uppercase">About Ahnaf</span>
          <div className="w-6 h-px bg-gray-600 mt-2" />
        </motion.div>

        {/* First Block */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-24 mb-24 lg:mb-32">
          <motion.div
            {...fadeInUp}
            className="order-2 lg:order-1"
          >
            <img
              src={`${import.meta.env.BASE_URL}gallery-graffiti.jpg`}
              alt="Creative work"
              className="w-full h-auto grayscale"
            />
            <p className="mt-4 text-xs text-gray-500 tracking-widest uppercase">
              TURNING IDEAS INTO DIGITAL EXPERIENCES
            </p>
          </motion.div>

          <motion.div
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.2 }}
            className="order-1 lg:order-2 flex items-center"
          >
            <p className="text-base lg:text-lg text-gray-300 leading-relaxed">
              Turning ideas into digital experiences, one creation at a time. 
              I believe great design isn't just about how things look, but how 
              they make people feel.
            </p>
          </motion.div>
        </div>

        {/* Quote Block */}
        <motion.div
          {...fadeInUp}
          className="mb-24 lg:mb-32"
        >
          <h2 className="font-display text-[8vw] lg:text-section leading-none tracking-tight text-gray-300">
            "STUDENT BY STATUS,<br />
            <span className="text-white underline underline-offset-8">ENTREPRENEUR BY MINDSET,</span><br />
            CREATOR BY PASSION."
          </h2>
          <p className="mt-6 text-sm text-gray-500 tracking-widest uppercase">
            PORTFOLIO TAGLINE
          </p>
        </motion.div>

        {/* Second Block */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-24 mb-24 lg:mb-32">
          <motion.div
            {...fadeInUp}
            className="flex items-center lg:text-right"
          >
            <p className="text-base lg:text-lg text-gray-300 leading-relaxed">
              A student with a creative mind, a curious soul, and a slightly 
              crazy mentality. I love experimenting with ideas, building cool 
              things, and turning imagination into reality. I believe in 
              thinking differently, learning endlessly, and creating things 
              that stand out. Still learning, always building, never settling.
            </p>
          </motion.div>

          <motion.div
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.2 }}
          >
            <img
              src={`${import.meta.env.BASE_URL}gallery-cameras.jpg`}
              alt="Behind the lens"
              className="w-full h-auto grayscale hover:grayscale-0 transition-all duration-700"
            />
            <p className="mt-4 text-xs text-gray-500 tracking-widest uppercase">
              STILL LEARNING, ALWAYS BUILDING, NEVER SETTLING
            </p>
          </motion.div>
        </div>

        {/* Third Block */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-24">
          <motion.div {...fadeInUp}>
            <img
              src={`${import.meta.env.BASE_URL}gallery-disco.jpg`}
              alt="Building projects"
              className="w-full h-auto grayscale"
            />
            <p className="mt-4 text-xs text-gray-500 tracking-widest uppercase">
              WHAT I DO
            </p>
          </motion.div>

          <motion.div
            {...fadeInUp}
            transition={{ ...fadeInUp.transition, delay: 0.2 }}
            className="flex items-center"
          >
            <p className="text-base lg:text-lg text-gray-300 leading-relaxed">
              Currently balancing student life with my journey as a self-driven 
              entrepreneur. I spend my time learning, experimenting, building 
              websites, exploring new ideas, and turning creative visions into 
              real projects. I'm not just studying for the future — I'm 
              actively building mine.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
