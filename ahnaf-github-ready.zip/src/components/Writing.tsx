import { motion } from 'framer-motion'

const articles = [
  {
    title: 'Creative Writing',
    description: 'Turning thoughts and ideas into engaging words.',
  },
  {
    title: 'Content Writing',
    description: 'Creating interesting and audience-friendly content.',
  },
  {
    title: 'Public Speaking',
    description: 'Expressing ideas confidently and clearly.',
  },
  {
    title: 'Communication',
    description: 'Sharing thoughts, collaborating, and connecting with people.',
  },
  {
    title: 'Presentation',
    description: 'Presenting projects and ideas in an engaging way.',
  },
]

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-100px' },
  transition: { duration: 0.8, ease: 'easeOut' }
}

export function Writing() {
  return (
    <section id="writing" className="section-padding">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <motion.div {...fadeInUp} className="mb-16">
          <span className="text-sm text-gray-500 tracking-widest uppercase">Writing & Communication</span>
          <div className="w-6 h-px bg-gray-600 mt-2" />
        </motion.div>

        <motion.h2
          {...fadeInUp}
          className="font-display text-[10vw] lg:text-section leading-none tracking-tight mb-12 lg:mb-16"
        >
          WRITING
        </motion.h2>

        {/* Intro */}
        <motion.p
          {...fadeInUp}
          className="text-base lg:text-lg text-gray-300 leading-relaxed max-w-2xl mb-16 lg:mb-24"
        >
          I enjoy expressing ideas through writing and communicating with 
          confidence. Whether it's creating engaging content, presenting ideas, 
          or having meaningful conversations, I believe effective communication 
          is an important part of creativity and personal growth.
        </motion.p>

        {/* List */}
        <div className="space-y-0">
          {articles.map((article, index) => (
            <motion.div
              key={article.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="border-t border-gray-800 py-6 md:py-8 group hover:bg-gray-900/30 transition-colors px-4 -mx-4"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 md:gap-8">
                <h3 className="text-lg md:text-xl lg:text-2xl text-white font-light">
                  {article.title}
                </h3>
                <p className="text-sm lg:text-base text-gray-500 md:text-right md:max-w-md">
                  {article.description}
                </p>
              </div>
            </motion.div>
          ))}
          <div className="border-t border-gray-800" />
        </div>
      </div>
    </section>
  )
}
